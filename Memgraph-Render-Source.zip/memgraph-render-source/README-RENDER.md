# Memgraph Neural — Render deployment source

This is a sanitized deployment copy of the application source.

## Render service settings
- Runtime: Node
- Build command: `npm install --omit=dev`
- Start command: `npm start`
- Node: 24.x
- Environment:
  - `HOST=0.0.0.0`
  - `DATA_DIR=/var/data`
  - `ALLOW_LOCAL_DEMO=0`
  - `PUBLIC_ORIGIN=https://YOUR-RENDER-SERVICE.onrender.com` (set after Render assigns the service URL)
- Persistent disk mount path: `/var/data`

The app uses SQLite and stores uploaded file blobs under `DATA_DIR`. Attach a persistent disk at `/var/data` to preserve accounts, messages, and uploads across deploys/restarts. Without a persistent disk, this data may be lost when the instance is replaced or restarted.

The local SQLite database, token encryption key, uploaded user files, and bundled Windows Node runtime were intentionally excluded from this deployment copy. The app initializes a fresh database and generates a new encryption key on first start. Do not commit secrets or personal data.

The local-only demo sign-in is disabled on the public deployment. Create an account through the app's registration screen.
